package com.dusty.overflow.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Created by dusty on 7/21/17.
 */
@Controller
@RequestMapping("/tags")
public class Tags {
}
